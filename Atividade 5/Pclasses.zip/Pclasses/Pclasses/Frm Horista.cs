﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class Frm_Horista : Form
    {
        public Frm_Horista()
        {
            InitializeComponent();
        }

        private void btnSalarioMensal_Click(object sender, EventArgs e)
        {

        }

        private void btnInstanciar2_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();


            //set
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHora.Text);
            objHorista.SalarioHora= Convert.ToDouble(txtSalario.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFalta.Text);

            if (rbtnSim.Checked)
                objHorista.HomeOffice = 'S';
            else
                objHorista.HomeOffice = 'N';

            //get
            MessageBox.Show("Matrícula :" + objHorista.Matricula + "\n" + "Nome :" + objHorista.NomeEmpregado + "\n" + "Data Entrada: " + objHorista.DataEntradaEmpresa.ToShortDateString() + "\n" + "Salário Bruto: " +
                objHorista.SalarioBruto().ToString("N") + "\n" + "Tempo Empresa (dias): " + objHorista.TempoTrabalho() + '\n' + objHorista.VerificaHome());
        }
    }
}
