﻿namespace Pclasses
{
    partial class Frm_Mensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.btnMatricula = new System.Windows.Forms.Label();
            this.btnNome = new System.Windows.Forms.Label();
            this.btnSalarioMensal = new System.Windows.Forms.Label();
            this.btnDataEntrada = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.btnInstanciar1 = new System.Windows.Forms.Button();
            this.gbxHome = new System.Windows.Forms.GroupBox();
            this.rbtnNão = new System.Windows.Forms.RadioButton();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.btnInstanciar2 = new System.Windows.Forms.Button();
            this.gbxHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(359, 108);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 0;
            // 
            // btnMatricula
            // 
            this.btnMatricula.AutoSize = true;
            this.btnMatricula.Location = new System.Drawing.Point(221, 115);
            this.btnMatricula.Name = "btnMatricula";
            this.btnMatricula.Size = new System.Drawing.Size(50, 13);
            this.btnMatricula.TabIndex = 1;
            this.btnMatricula.Text = "Matricula";
            // 
            // btnNome
            // 
            this.btnNome.AutoSize = true;
            this.btnNome.Location = new System.Drawing.Point(221, 151);
            this.btnNome.Name = "btnNome";
            this.btnNome.Size = new System.Drawing.Size(35, 13);
            this.btnNome.TabIndex = 2;
            this.btnNome.Text = "Nome";
            // 
            // btnSalarioMensal
            // 
            this.btnSalarioMensal.AutoSize = true;
            this.btnSalarioMensal.Location = new System.Drawing.Point(221, 193);
            this.btnSalarioMensal.Name = "btnSalarioMensal";
            this.btnSalarioMensal.Size = new System.Drawing.Size(76, 13);
            this.btnSalarioMensal.TabIndex = 3;
            this.btnSalarioMensal.Text = "Sálario Mensal";
            // 
            // btnDataEntrada
            // 
            this.btnDataEntrada.AutoSize = true;
            this.btnDataEntrada.Location = new System.Drawing.Point(221, 236);
            this.btnDataEntrada.Name = "btnDataEntrada";
            this.btnDataEntrada.Size = new System.Drawing.Size(129, 13);
            this.btnDataEntrada.TabIndex = 4;
            this.btnDataEntrada.Text = "Data Entrada na Empresa";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(359, 148);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 5;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(359, 190);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(100, 20);
            this.txtSalario.TabIndex = 6;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(359, 231);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(100, 20);
            this.txtData.TabIndex = 7;
            // 
            // btnInstanciar1
            // 
            this.btnInstanciar1.Location = new System.Drawing.Point(222, 268);
            this.btnInstanciar1.Name = "btnInstanciar1";
            this.btnInstanciar1.Size = new System.Drawing.Size(120, 66);
            this.btnInstanciar1.TabIndex = 8;
            this.btnInstanciar1.Text = "Instanciar Mensalista";
            this.btnInstanciar1.UseVisualStyleBackColor = true;
            this.btnInstanciar1.Click += new System.EventHandler(this.btnInstanciar1_Click);
            // 
            // gbxHome
            // 
            this.gbxHome.Controls.Add(this.rbtnNão);
            this.gbxHome.Controls.Add(this.rbtnSim);
            this.gbxHome.Location = new System.Drawing.Point(859, 63);
            this.gbxHome.Name = "gbxHome";
            this.gbxHome.Size = new System.Drawing.Size(200, 100);
            this.gbxHome.TabIndex = 9;
            this.gbxHome.TabStop = false;
            this.gbxHome.Text = "Trabalha em Home Office";
            // 
            // rbtnNão
            // 
            this.rbtnNão.AutoSize = true;
            this.rbtnNão.Location = new System.Drawing.Point(7, 76);
            this.rbtnNão.Name = "rbtnNão";
            this.rbtnNão.Size = new System.Drawing.Size(45, 17);
            this.rbtnNão.TabIndex = 1;
            this.rbtnNão.TabStop = true;
            this.rbtnNão.Text = "Não";
            this.rbtnNão.UseVisualStyleBackColor = true;
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(7, 52);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(42, 17);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "Sim";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // btnInstanciar2
            // 
            this.btnInstanciar2.Location = new System.Drawing.Point(348, 268);
            this.btnInstanciar2.Name = "btnInstanciar2";
            this.btnInstanciar2.Size = new System.Drawing.Size(119, 66);
            this.btnInstanciar2.TabIndex = 10;
            this.btnInstanciar2.Text = "Instanciar Horista";
            this.btnInstanciar2.UseVisualStyleBackColor = true;
            // 
            // Frm_Mensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 515);
            this.Controls.Add(this.btnInstanciar2);
            this.Controls.Add(this.gbxHome);
            this.Controls.Add(this.btnInstanciar1);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.btnDataEntrada);
            this.Controls.Add(this.btnSalarioMensal);
            this.Controls.Add(this.btnNome);
            this.Controls.Add(this.btnMatricula);
            this.Controls.Add(this.txtMatricula);
            this.Name = "Frm_Mensalista";
            this.Text = " ";
            this.gbxHome.ResumeLayout(false);
            this.gbxHome.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label btnMatricula;
        private System.Windows.Forms.Label btnNome;
        private System.Windows.Forms.Label btnSalarioMensal;
        private System.Windows.Forms.Label btnDataEntrada;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Button btnInstanciar1;
        private System.Windows.Forms.GroupBox gbxHome;
        private System.Windows.Forms.RadioButton rbtnNão;
        private System.Windows.Forms.RadioButton rbtnSim;
        private System.Windows.Forms.Button btnInstanciar2;
    }
}